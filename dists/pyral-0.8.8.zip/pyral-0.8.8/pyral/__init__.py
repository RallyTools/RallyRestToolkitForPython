__version__ = (0, 8, 8)
from .config    import rallySettings
from .restapi   import Rally, RallyRESTAPIError
from .rallyresp import RallyRESTResponse

