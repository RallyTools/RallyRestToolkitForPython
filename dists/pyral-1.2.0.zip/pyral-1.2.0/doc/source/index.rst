.. pyral documentation master file, created by
   sphinx-quickstart on Sat Jun 11 13:18:28 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Python toolkit for the Rally REST API
=====================================

The official name for this software is **Python toolkit for the Rally REST API**.  

The actual name of the package installed is **pyral**.

Contents:

.. toctree::
   :maxdepth: 2

   overview
   interface

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

